# References

1. **GIZ (2021)** – 6-step Climate Risk Assessment methodology.
2. **Carlone, T.; Mannocchi, M. (2023)** – Case study on NbS in Emilia-Romagna.
3. **ARPAE Emilia-Romagna (2017)** – Climate atlas report documenting temperature increases.
4. **CLIMAAX Project (2023)** – Climate Risk Assessment Toolbox Handbook.
5. **IPCC (2021)** – Sixth Assessment Report.
