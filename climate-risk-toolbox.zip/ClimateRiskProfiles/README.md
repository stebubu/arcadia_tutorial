# Climate Risk Profiles

Climate Risk Profiles provide a snapshot of climate hazards, exposures, and vulnerabilities for specific cities or regions. This section summarizes key hazards such as floods, droughts, wildfires, and heatwaves, and shows how to integrate local data into risk assessments.
